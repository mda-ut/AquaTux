Board: InterfaceBoard
Date: 2012-02-12
Designer: Jordan Varley
Board Dimensions: 6.000 x 4.000 inches


List of Files:
--------------
*.drd   Excellon drill description
*.dri   Excellon drill tool description
*.cmp   Component (top) side copper
*.sol   Solder (bottom) side copper
*.plc   Component (top) side silk screen data (includes board outline)
*.stc   Component (top) side solder stop mask data
*.sts   Solder (bottom) side solder stop mask data
*.gpi	Gerber photoplotter information data